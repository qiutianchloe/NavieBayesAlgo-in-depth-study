import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.tiled.TiledMap;

/**
 * This class should be used to contain all the different objects in your game world, and schedule their interactions.
 * 
 * You are free to make ANY modifications you see fit.
 * These classes are provided simply as a starting point. You are not strictly required to use them.
 */
public class World {
	//the attribute of the class World
	
	
	// create the tile map
	static TiledMap map;	
	
	// create the variable associate with the tile map
	//the width and height of map in pixels
	private static int mapWidth, mapHeight;  
		
	//create the camera
	static Camera camera;
		
	//create the scout
	static Player scout; 
	
	
	
	
	//the method of the class World
	
	
	//the constructor to initialize all the value
	public World() {
		try {
			//import the tile map
			map = new TiledMap("assets/main.tmx", "assets");
			
			//calculate the tile map Width in pixels
			mapWidth = map.getWidth()*map.getTileWidth();
			
			//calculate the tile map Height in pixels
			mapHeight = map.getHeight()*map.getTileHeight(); 
			
			//create an object of Class Player and name it scout 
			scout = new Player("assets/scout.png",mapWidth,mapHeight); 
			
			//create an object of Class Camera and name it camera
			camera = new Camera(scout.getScoutX(), scout.getScoutY(), mapWidth, mapHeight); 
			
		}catch(SlickException e) {
			e.printStackTrace(); 
		}
	}
	
	
	//Slick2D functions update and render
	public void update(Input input, int delta) {
		
		//update the coordinates of the scout
		//by calling the move function in the Player class
		
		scout.move(input, delta);		
	}
	
	public void render(Graphics g) {
		
		//make the camera move with the scout so that control the screen to the certain point of the map
		camera.translate(g);
		
		//draw the map
		map.render(0, 0);
		
		//call the draw function in Player Class to make it move
		scout.draw(); 
		
	}
	
	//getter Method
	
	//return the x position of scout
	public static float getScoutX() {
		return scout.getScoutX(); 
	}
	//return the y position of scout
	public static float getScoutY() {
		return scout.getScoutY(); 
	}
	
	//return the x position of camera
	public static float getCameraY() {
		return camera.getY();
	}
	
	//return the y position of camera
	public static float getCameraX() {
		return camera.getX();
	}
}
