import org.newdawn.slick.Graphics;

/**
 * This class should be used to restrict the game's view to a subset of the entire world.
 * 
 * You are free to make ANY modifications you see fit.
 * These classes are provided simply as a starting point. You are not strictly required to use them.
 */
public class Camera {
	// the attribute of the Class Camera
	
	// the x position of the camera
	private static float cameraX;
	// the y position of the camera 
	private static float cameraY; 
	// the height and width of the map
	private int mapWidth, mapHeight; 
	
	// the method of the Class Camera
	
	public Camera(float initialX, float initialY, int mapWidth, int mapHeight) {
		
		// get the initial position of the scout 
		// and the height and width of the map
		this.mapHeight = mapHeight; 
		this.mapWidth = mapWidth; 
		
		/*For the x position of the Camera*/
		
		//if the x is smaller than the start of half of the screen width 
		//then set 0
		if(initialX<App.WINDOW_WIDTH/2) {
			cameraX=0; 
		}
		//if the x is greater than the end of half of the screen width 
		//then set window width minus map width
		else if(initialX>mapWidth-App.WINDOW_WIDTH/2) {
			cameraX = App.WINDOW_WIDTH-mapWidth;
		}
		//if the x is in the middle part of screen width 
		//then set window width minus scout x 
		else{
			cameraX = App.WINDOW_WIDTH/2-initialX; 
		}
		
		/*For the y position of the Camera*/
		
		//if the y is smaller than the start of half of the screen height 
		//then set 0
		if(initialY<App.WINDOW_HEIGHT/2) {
			cameraY=0; 
		}		
		//if the y is greater than the end of half of the screen height
		//then set window height minus map height
		else if(initialY>mapHeight-App.WINDOW_HEIGHT/2) {
			cameraY = App.WINDOW_HEIGHT-mapHeight;
		}
		//if the y is in the middle part of screen height
		//then set window height minus scout y
		else {
			cameraY = App.WINDOW_HEIGHT/2-initialY; 
		}
	}
	
	public void translate(Graphics g) {
		
        /*For the x position of the Camera*/
		
		//if the x is smaller than the start of half of the screen width 
		//then set 0
		if(World.getScoutX()<App.WINDOW_WIDTH/2) {
			cameraX=0; 
		}
		//if the x is greater than the end of half of the screen width 
		//then set window width minus map width
		else if(World.getScoutX()>mapWidth-App.WINDOW_WIDTH/2) {
			cameraX = App.WINDOW_WIDTH-mapWidth;
		}
		//if the x is in the middle part of screen width 
		//then set window width minus scout x
		else {
			cameraX = App.WINDOW_WIDTH/2-World.getScoutX(); 
		}
		
		/*For the y position of the Camera*/
		
		//if the y is smaller than the start of half of the screen height 
		//then set 0
		if(World.getScoutY()<App.WINDOW_HEIGHT/2) {
			cameraY= 0; 
		}
		//if the y is greater than the end of half of the screen height
		//then set window height minus map height
		else if(World.getScoutY()>mapHeight-App.WINDOW_HEIGHT/2) {
			cameraY = App.WINDOW_HEIGHT-mapHeight;
		}
		//if the y is in the middle part of screen height
		//then set window height minus scout y
		else {
			cameraY = App.WINDOW_HEIGHT/2-World.getScoutY(); 
		}
		
		//translate the screen by the position of the camera
		g.translate(cameraX, cameraY);
	}
	
	
	//getter method
	//return the value of the x position of camera
	public float getX() {
		return cameraX; 
	}
	//return the value of the y postision of camera
	public float getY() {
		return cameraY; 
	}

}
