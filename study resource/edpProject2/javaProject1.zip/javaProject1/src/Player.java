import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class Player {
	
	// the attribute of the Class Player 
	
	// the Image of player , in this case, call it scout first
	private Image scout; 
	// the x position of scout 
	private static float scoutX;
	// the y position of scout 
	private static float scoutY;  
	
	//the constant value of Speed
	public static final float SPEED=0.25f;
	
	
	// the method of the the Class Player 
	
	// the constructor method 
	public Player(String file, int mapWidth, int mapHeight) throws SlickException {
		
		//initialize the value of the Player
		
		//create a visual image for the player 
		scout = new Image(file);
		
		//make the scout at the middle of the map
		//make the initial x position of scout at the middle of the map width
		scoutX = mapWidth/2; 
		//make the initial y position of scout at the middle of the map height
		scoutY = mapHeight/2;	
	}
	
	// the method to update the coordinates of scout 
	public void move(Input input, int delta) {
		//check the mouse condition
		if(input.isMouseButtonDown(Input.MOUSE_RIGHT_BUTTON)) {
			// if the left button of the mouse is pressed
			
			
			// record the x and y position of mouse 
			float mouseX = input.getMouseX()-24; 
			float mouseY = input.getMouseY()-18; 
			
			// calculate the value of the angle between mouse and scout 
			// cause the mouse position is related to the screen and scout position is related to the map 
			// so we need the camera value position to deal with this problem to make them in the same scale 
			double angle = Math.atan2(mouseY-World.getCameraY()-scoutY, mouseX-World.getCameraX()-scoutX);
			
			//get the next position coordinates of the scout 
			float newXPosition = (float) (scoutX+SPEED*Math.cos(angle)*delta); 
			float newYPosition = (float) (scoutY+SPEED*Math.sin(angle)*delta); 
			
			//use the function of isSolid to check whether it is unreachable
			if(!isSolid(newXPosition, newYPosition)) {
				//if the next tile is reachable, make the scout go through it according to the relation of the scout and mouse
				scoutX = (float)newXPosition; 
				scoutY = (float)newYPosition; 
			}
		}
	}
	
	//function isSolid is to check whether the certain point is solid or not
	public boolean isSolid(float nextx, float nexty) {
		
		//get the point in the map and identify which tile it is in
		int checkx = (int)nextx/World.map.getTileWidth(); 
		int checky = (int)nexty/World.map.getTileHeight(); 
		//get the id of the certain tile
		int currentId = World.map.getTileId(checkx, checky, 0); 
		//check the 'solid' property of this tile
		String property = World.map.getTileProperty(currentId, "solid", "true");
		//if the property is true then this tile is solid return true
		if("true".equals(property)) {
			return true; 
		}
		//otherwise return false
		else {
			return false; 
		}
	}
	
	//getter method
	//getter method to return the x position of scout
	public float getScoutX() {
		return scoutX; 
	}
	//getter method to return the y position of scout 
	public float getScoutY() {
		return scoutY; 
	}
	
	//draw method to make the scout on the screen by the value of the scout 
	public void draw() {
		scout.draw(scoutX, scoutY); 		
	}

}
